.. _reference.feed.publisher:

:py:attr:`feed.publisher`
=========================

The publisher of the feed.


.. rubric:: Comes from

* /rdf:RDF/rdf:channel/dc:publisher
* /rss/channel/dc:publisher
* /rss/channel/itunes:owner
* /rss/channel/webMaster


.. seealso::

    * :ref:`reference.feed.publisher_detail`
