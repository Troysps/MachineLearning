:abbr:`HTTP (Hypertext Transfer Protocol)` Features
###################################################

.. toctree::
   :maxdepth: 2

   http-etag
   http-useragent
   http-redirect
   http-authentication
   http-other
